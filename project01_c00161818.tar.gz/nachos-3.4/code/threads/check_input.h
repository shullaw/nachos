char* get_input();
void shout(int user_input);
void check_input(int user_input);
void no_leak(char *);